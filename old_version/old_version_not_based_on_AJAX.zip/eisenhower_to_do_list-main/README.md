# Eisenhower To do list
A simple To Do List based on Eisenhower concept of priority.  
This software runs on a simple Nginx or Apache server, also online, so you can share your to-do list between devices.

> Please help me to improve this software.

# Installation
- Clone this repository into a served directory.  
- Browse the directory and enjoy.

  
![Screenshot](https://github.com/TheFax/eisenhower_to_do_list/blob/main/screenshot.jpg?raw=true)


# Dependencies
You need PHP and a http/https served folder.
The software will create itself the database in a file, via MySQLlite.


